package udacity.popular_movie_stage1;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import java.util.List;

/**
 * Created by lenovo-pc on 7/15/2018.
 */
@Dao
public interface FavouriteDao {


    @Query("SELECT * FROM Favourite where IsFavourite = :isFavourite")
    List<FavouriteModel> getAll(Boolean isFavourite);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(FavouriteModel products);

    @Query("UPDATE Favourite SET IsFavourite = :isFavourite where id = :id")
    void update(int id, Boolean isFavourite);

    @Delete
    void delete(FavouriteModel product);

    @Query("SELECT * FROM Favourite where id = :id")
    FavouriteModel getMovie(String id);
}

